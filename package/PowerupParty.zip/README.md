## Usage

Open inventory, click on powerup, select player.

## Changelog

### 1.0.3

- Maked UI look better.

Special thanks to Terrain and other guys from Muck Modding discord for helping me.
Art by owlq.