## Usage

Open inventory, click on powerup, select player.

## Changelog

### 1.1.0

- Fix for OffroadPackets 2.0 (and also works only with 2.0 now)

### 1.0.3

- Maked UI look better.

Special thanks to Terrain and other guys from Muck Modding discord for helping me.
Art by owlq.