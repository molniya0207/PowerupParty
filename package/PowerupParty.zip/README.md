## Usage

Open inventory, click on powerup, select player. If process was successful, you will see message in chat.

Special thanks to Terrain and other guys from Muck Modding discord for helping me.
Art by owlq.